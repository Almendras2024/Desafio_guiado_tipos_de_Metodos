from personaje import Personaje
import random

print("¡Bienvenido a Gran Realidad!")
nombre = input(
    "Por favor indique el nombre de su personaje:\n"
)

# Crear una instancia del personaje con el nombre ingresado
p = Personaje(nombre)
print(p.estado)

print(
    "\n¡Oh no!, ¡Ha aparecido un Orco!"
)

# Crear una instancia del personaje Orco
o = Personaje("Orco")

# Calcular la probabilidad de ganar del personaje contra el Orco
probabilidad_ganar = p.get_probabilidad_ganar(o)
print(f"Probabilidad de ganar contra el Orco: {probabilidad_ganar * 100}%")

# Mostrar el menú de opciones al usuario
opcion_orco = Personaje.mostrar_dialogo_opcion(probabilidad_ganar)

while opcion_orco == 2:
    # Generar un número aleatorio entre 0 y 1 para determinar el resultado del ataque
    resultado_ataque = random.uniform(0, 1)

    if resultado_ataque <= probabilidad_ganar:
        # Si el resultado es menor o igual que la probabilidad de ganar, el jugador gana
        print(
            "\n¡Le has ganado al orco, felicidades!\n"
            "¡Recibirás 50 puntos de experiencia!\n"
        )
        # Actualizar la experiencia del jugador y del orco
        p.estado = 50
        o.estado = -30
    else:
        # Si el resultado es mayor que la probabilidad de ganar, el orco gana
        print(
            "\n¡Oh no! ¡El orco te ha ganado!\n"
            "¡Has perdido 30 puntos de experiencia!\n"
        )
        # Actualizar la experiencia del jugador y del orco
        p.estado = -30
        o.estado = 50

    # Mostrar los estados actualizados de los personajes
    print(f"\nEstado de {p.nombre}: NIVEL {p.nivel}, EXP {p.experiencia}")
    print(f"Estado de {o.nombre}: NIVEL {o.nivel}, EXP {o.experiencia}")

    # Mostrar el estado completo de los personajes
    print(f"\nEstado de {p.nombre}:\n{p.estado}")
    print(f"Estado de {o.nombre}:\n{o.estado}")

    # Recalcular la probabilidad de ganar del jugador contra el Orco
    probabilidad_ganar = p.get_probabilidad_ganar(o)

    # Consultar al jugador su opción de juego nuevamente
    opcion_orco = Personaje.mostrar_dialogo_opcion(probabilidad_ganar)

    # Si el jugador elige huir, se rompe el ciclo
    if opcion_orco == 1:
        print("\nHas decidido huir, el Orco ha quedado atrás.")
        break
